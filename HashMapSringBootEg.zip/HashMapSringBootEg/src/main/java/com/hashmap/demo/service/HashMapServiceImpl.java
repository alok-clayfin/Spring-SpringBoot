package com.hashmap.demo.service;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hashmap.demo.repository.HashMapRepository;

@Service
public class HashMapServiceImpl implements HashMapService{

	@Autowired
	private HashMapRepository hashMapRepository;

	@Override
	public HashMap<Integer, String> getAll() {
		HashMap<Integer, String> hashMap = hashMapRepository.getAll();
		return hashMap;
	}

//	@Override
//	public String getById() {
//		hashMapRepository.getById();
//		return "";
//	}
//	
	
}
