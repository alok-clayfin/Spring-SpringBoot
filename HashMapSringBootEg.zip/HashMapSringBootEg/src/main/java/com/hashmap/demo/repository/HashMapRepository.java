package com.hashmap.demo.repository;

import java.util.HashMap;

public interface HashMapRepository {

	HashMap<Integer, String> getAll();

}
