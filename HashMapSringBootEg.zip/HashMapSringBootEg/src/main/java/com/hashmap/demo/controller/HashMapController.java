package com.hashmap.demo.controller;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hashmap.demo.service.HashMapService;

@RestController
public class HashMapController {
	@Autowired
	private HashMapService hashMapService;
	
	@GetMapping("/getAll")
	public HashMap<Integer,String> getAll() {
		HashMap<Integer,String> hashMap = hashMapService.getAll();
		 return hashMap;
	}
}
