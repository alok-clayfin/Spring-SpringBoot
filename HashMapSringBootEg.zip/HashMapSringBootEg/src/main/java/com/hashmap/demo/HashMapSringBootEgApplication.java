package com.hashmap.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HashMapSringBootEgApplication {

	public static void main(String[] args) {
		SpringApplication.run(HashMapSringBootEgApplication.class, args);
	}

}
