package com.hashmap.demo.repository;

import java.util.HashMap;

import org.springframework.stereotype.Repository;
@Repository
public class HashMapRepositoryImpl implements HashMapRepository{
	
	HashMap<Integer,String> hashMap = new HashMap<>();
	public HashMapRepositoryImpl() {
		
		hashMap.put(1,"vamsi");
		hashMap.put(2,"rayudu");
		hashMap.put(3,"peter");
	}
	
	@Override
	public HashMap<Integer, String> getAll() {
		
		return hashMap;
	}

//	@Override
//	public void getById() {
//		
//		
//	}
}
	