package com.hashmap.demo.service;

import java.util.HashMap;

public interface HashMapService {

	HashMap<Integer, String> getAll();

}
