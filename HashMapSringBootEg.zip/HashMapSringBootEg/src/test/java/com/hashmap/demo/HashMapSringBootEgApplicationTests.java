package com.hashmap.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HashMapSringBootEgApplicationTests {

	@Test
	void contextLoads() {
	}

}
