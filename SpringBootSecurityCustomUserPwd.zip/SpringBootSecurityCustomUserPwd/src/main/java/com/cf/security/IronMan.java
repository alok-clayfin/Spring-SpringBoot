package com.cf.security;

import org.springframework.stereotype.Component;

@Component
public class IronMan {
public IronMan() {
	System.out.println("iron man");
}
}
