package com.cf.security;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;


@SpringBootApplication(scanBasePackages = "com.cf.*")
//@ComponentScan(basePackages= "co.cf.*")
public class SpringBootSecurity1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootSecurity1Application.class, args);
	}
 
}
