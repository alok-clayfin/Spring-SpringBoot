package com.cf.anotherpkg;

import org.springframework.stereotype.Component;

@Component
public class CaptainAmerica {
public CaptainAmerica() {
	System.out.println("Captain America");
}
}
