package com.example.demo;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@ConfigurationProperties
@Configuration
@SpringBootApplication
@Getter
@Setter
@NoArgsConstructor
public class LombokUsages {
	@Value("${user.firstName}") 
	private String firstName;
    public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	@Value("${user.lastName}") 
    private String lastName;
    
	@Override
	public String toString() {
		return "SimpleSpringPropertyTest [firstName=" + firstName + ", lastName=" + lastName + "]";
	}

}
