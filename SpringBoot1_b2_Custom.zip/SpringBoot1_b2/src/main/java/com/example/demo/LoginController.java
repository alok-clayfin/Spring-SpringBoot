package com.example.demo;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@RestController//@RespBody+@Controller
public class LoginController {

	//@RequestMapping()
	@GetMapping("/login")
	public boolean login() {
		return true;
	}
	@GetMapping("/profile")
	public boolean showProfile() {
		return true;
	}
	@GetMapping("/")
	public String dashboard() {
		return "home page of my application";
	}
	
	
	
}
